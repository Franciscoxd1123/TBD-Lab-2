--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.4
-- Dumped by pg_dump version 16.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "Ecommerce";
--
-- Name: Ecommerce; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "Ecommerce" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Spanish_Chile.1252';


ALTER DATABASE "Ecommerce" OWNER TO postgres;

\connect "Ecommerce"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: Ecommerce; Type: DATABASE PROPERTIES; Schema: -; Owner: postgres
--

ALTER DATABASE "Ecommerce" SET search_path TO '$user', 'public', 'topology';


\connect "Ecommerce"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: topology; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA topology;


ALTER SCHEMA topology OWNER TO postgres;

--
-- Name: SCHEMA topology; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA topology IS 'PostGIS Topology schema';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry and geography spatial types and functions';


--
-- Name: postgis_topology; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS postgis_topology WITH SCHEMA topology;


--
-- Name: EXTENSION postgis_topology; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis_topology IS 'PostGIS topology spatial types and functions';


--
-- Name: fn_gestionar_inventario(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_gestionar_inventario() RETURNS trigger
    LANGUAGE plpgsql
    AS $$BEGIN
    -- Determinar la operación
    CASE TG_OP
        WHEN 'INSERT' THEN
            -- Restar del inventario cuando se agrega un producto
            UPDATE producto 
            SET 
                stock = stock - NEW.cantidad,
                estado = CASE 
                    WHEN (stock - NEW.cantidad) <= 0 THEN 'Agotado'
                    ELSE 'Disponible'
                END
            WHERE id_producto = NEW.id_producto;
            
        WHEN 'DELETE' THEN
            -- Sumar al inventario cuando se elimina un producto
            UPDATE producto 
            SET 
                stock = stock + OLD.cantidad,
                estado = CASE 
                    WHEN (stock + OLD.cantidad) > 0 THEN 'Disponible'
                    ELSE 'Agotado'
                END
            WHERE id_producto = OLD.id_producto;
    END CASE;

    -- Retornar el valor apropiado según la operación
    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    ELSE
        RETURN NEW;
    END IF;
END;$$;


ALTER FUNCTION public.fn_gestionar_inventario() OWNER TO postgres;

--
-- Name: fn_registrar_auditoria(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.fn_registrar_auditoria() RETURNS trigger
    LANGUAGE plpgsql
    AS $$DECLARE
    datos JSONB;
    operacion VARCHAR(50);
BEGIN
    -- Obtener el tipo de operación
    CASE TG_OP
        WHEN 'INSERT' THEN
            operacion := 'INSERT';
            datos := to_jsonb(NEW);
        WHEN 'UPDATE' THEN
            operacion := 'UPDATE';
            datos := jsonb_build_object(
                'anterior', to_jsonb(OLD),
                'nuevo', to_jsonb(NEW)
            );
        WHEN 'DELETE' THEN
            operacion := 'DELETE';
            datos := to_jsonb(OLD);
    END CASE;

    -- Insertar en la tabla de auditoría
    INSERT INTO log_auditoria (
        usuario,
        operacion,
        tabla,
        datos,
        fecha
    ) VALUES (
        CURRENT_USER,         -- Usuario actual de la base de datos
        operacion,           -- Tipo de operación (INSERT, UPDATE, DELETE)
        TG_TABLE_NAME,       -- Nombre de la tabla
        datos,              -- Datos en formato JSON
        CURRENT_TIMESTAMP    -- Fecha y hora actual
    );

    -- Retornar NEW para INSERT/UPDATE o OLD para DELETE
    IF TG_OP = 'DELETE' THEN
        RETURN OLD;
    ELSE
        RETURN NEW;
    END IF;
END;$$;


ALTER FUNCTION public.fn_registrar_auditoria() OWNER TO postgres;

--
-- Name: reporte_usuarios_mas_activos(); Type: PROCEDURE; Schema: public; Owner: postgres
--

CREATE PROCEDURE public.reporte_usuarios_mas_activos()
    LANGUAGE plpgsql
    AS $$DECLARE
    reporte_general RECORD;
    reporte_detallado RECORD;
BEGIN
    -- Reportar los usuarios más activos en general
    RAISE NOTICE 'Usuarios con más operaciones en total:';
    FOR reporte_general IN 
        SELECT 
            usuario,
            COUNT(*) AS total_operaciones
        FROM log_auditoria
        GROUP BY usuario
        ORDER BY total_operaciones DESC
        LIMIT 10
    LOOP
        RAISE NOTICE 'Usuario: %, Total de Operaciones: %', reporte_general.usuario, reporte_general.total_operaciones;
    END LOOP;

    -- Reportar los detalles de operaciones por usuario
    RAISE NOTICE 'Detalle de operaciones por usuario:';
    FOR reporte_detallado IN 
        SELECT 
            usuario,
            operacion,
            COUNT(*) AS total_por_operacion
        FROM log_auditoria
        GROUP BY usuario, operacion
        ORDER BY usuario, total_por_operacion DESC
    LOOP
        RAISE NOTICE 'Usuario: %, Operación: %, Total por Operación: %', reporte_detallado.usuario, reporte_detallado.operacion, reporte_detallado.total_por_operacion;
    END LOOP;
END;$$;


ALTER PROCEDURE public.reporte_usuarios_mas_activos() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: almacen; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.almacen (
    id_almacen integer NOT NULL,
    nombre character varying(255) NOT NULL,
    direccion character varying(255) NOT NULL,
    latitud double precision,
    longitud double precision,
    location public.geometry(Point,4326)
);


ALTER TABLE public.almacen OWNER TO postgres;

--
-- Name: almacen_id_almacen_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.almacen_id_almacen_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.almacen_id_almacen_seq OWNER TO postgres;

--
-- Name: almacen_id_almacen_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.almacen_id_almacen_seq OWNED BY public.almacen.id_almacen;


--
-- Name: almacen_producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.almacen_producto (
    id_almacen_producto integer NOT NULL,
    id_almacen integer,
    id_producto integer,
    cantidad integer NOT NULL,
    fecha_entrada date,
    fecha_salida date
);


ALTER TABLE public.almacen_producto OWNER TO postgres;

--
-- Name: almacen_producto_id_almacen_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.almacen_producto_id_almacen_producto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.almacen_producto_id_almacen_producto_seq OWNER TO postgres;

--
-- Name: almacen_producto_id_almacen_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.almacen_producto_id_almacen_producto_seq OWNED BY public.almacen_producto.id_almacen_producto;


--
-- Name: categoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.categoria (
    id_categoria integer NOT NULL,
    nombre character varying(100)
);


ALTER TABLE public.categoria OWNER TO postgres;

--
-- Name: categoria_id_categoria_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.categoria_id_categoria_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categoria_id_categoria_seq OWNER TO postgres;

--
-- Name: categoria_id_categoria_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.categoria_id_categoria_seq OWNED BY public.categoria.id_categoria;


--
-- Name: cliente; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cliente (
    id_cliente integer NOT NULL,
    nombre character varying(255),
    direccion character varying(255),
    email character varying(100),
    telefono character varying(20),
    password character varying(100),
    latitud double precision,
    longitud double precision,
    location public.geometry(Point,4326)
);


ALTER TABLE public.cliente OWNER TO postgres;

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.cliente_id_cliente_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.cliente_id_cliente_seq OWNER TO postgres;

--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.cliente_id_cliente_seq OWNED BY public.cliente.id_cliente;


--
-- Name: detalle_orden; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.detalle_orden (
    id_detalle integer NOT NULL,
    id_orden integer,
    id_producto integer,
    cantidad integer,
    precio_unitario numeric(10,2)
);


ALTER TABLE public.detalle_orden OWNER TO postgres;

--
-- Name: detalle_orden_id_detalle_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.detalle_orden_id_detalle_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.detalle_orden_id_detalle_seq OWNER TO postgres;

--
-- Name: detalle_orden_id_detalle_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.detalle_orden_id_detalle_seq OWNED BY public.detalle_orden.id_detalle;


--
-- Name: log_auditoria; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.log_auditoria (
    id_log integer NOT NULL,
    usuario character varying(255),
    operacion character varying(50),
    tabla character varying(50),
    datos jsonb,
    fecha timestamp without time zone DEFAULT CURRENT_TIMESTAMP
);


ALTER TABLE public.log_auditoria OWNER TO postgres;

--
-- Name: log_auditoria_id_log_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.log_auditoria_id_log_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.log_auditoria_id_log_seq OWNER TO postgres;

--
-- Name: log_auditoria_id_log_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.log_auditoria_id_log_seq OWNED BY public.log_auditoria.id_log;


--
-- Name: orden; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.orden (
    id_orden integer NOT NULL,
    fecha_orden timestamp without time zone,
    estado character varying(50),
    id_cliente integer,
    total numeric(10,2)
);


ALTER TABLE public.orden OWNER TO postgres;

--
-- Name: orden_id_orden_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.orden_id_orden_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.orden_id_orden_seq OWNER TO postgres;

--
-- Name: orden_id_orden_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.orden_id_orden_seq OWNED BY public.orden.id_orden;


--
-- Name: producto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.producto (
    id_producto integer NOT NULL,
    nombre character varying(255),
    descripcion text,
    precio numeric(10,2),
    stock integer,
    estado character varying(50),
    id_categoria integer
);


ALTER TABLE public.producto OWNER TO postgres;

--
-- Name: producto_id_producto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.producto_id_producto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.producto_id_producto_seq OWNER TO postgres;

--
-- Name: producto_id_producto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.producto_id_producto_seq OWNED BY public.producto.id_producto;


--
-- Name: almacen id_almacen; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.almacen ALTER COLUMN id_almacen SET DEFAULT nextval('public.almacen_id_almacen_seq'::regclass);


--
-- Name: almacen_producto id_almacen_producto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.almacen_producto ALTER COLUMN id_almacen_producto SET DEFAULT nextval('public.almacen_producto_id_almacen_producto_seq'::regclass);


--
-- Name: categoria id_categoria; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria ALTER COLUMN id_categoria SET DEFAULT nextval('public.categoria_id_categoria_seq'::regclass);


--
-- Name: cliente id_cliente; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente ALTER COLUMN id_cliente SET DEFAULT nextval('public.cliente_id_cliente_seq'::regclass);


--
-- Name: detalle_orden id_detalle; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_orden ALTER COLUMN id_detalle SET DEFAULT nextval('public.detalle_orden_id_detalle_seq'::regclass);


--
-- Name: log_auditoria id_log; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_auditoria ALTER COLUMN id_log SET DEFAULT nextval('public.log_auditoria_id_log_seq'::regclass);


--
-- Name: orden id_orden; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden ALTER COLUMN id_orden SET DEFAULT nextval('public.orden_id_orden_seq'::regclass);


--
-- Name: producto id_producto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto ALTER COLUMN id_producto SET DEFAULT nextval('public.producto_id_producto_seq'::regclass);


--
-- Data for Name: almacen; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.almacen (id_almacen, nombre, direccion, latitud, longitud, location) FROM stdin;
\.
COPY public.almacen (id_almacen, nombre, direccion, latitud, longitud, location) FROM '$$PATH$$/5949.dat';

--
-- Data for Name: almacen_producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.almacen_producto (id_almacen_producto, id_almacen, id_producto, cantidad, fecha_entrada, fecha_salida) FROM stdin;
\.
COPY public.almacen_producto (id_almacen_producto, id_almacen, id_producto, cantidad, fecha_entrada, fecha_salida) FROM '$$PATH$$/5951.dat';

--
-- Data for Name: categoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.categoria (id_categoria, nombre) FROM stdin;
\.
COPY public.categoria (id_categoria, nombre) FROM '$$PATH$$/5939.dat';

--
-- Data for Name: cliente; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cliente (id_cliente, nombre, direccion, email, telefono, password, latitud, longitud, location) FROM stdin;
\.
COPY public.cliente (id_cliente, nombre, direccion, email, telefono, password, latitud, longitud, location) FROM '$$PATH$$/5941.dat';

--
-- Data for Name: detalle_orden; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.detalle_orden (id_detalle, id_orden, id_producto, cantidad, precio_unitario) FROM stdin;
\.
COPY public.detalle_orden (id_detalle, id_orden, id_producto, cantidad, precio_unitario) FROM '$$PATH$$/5947.dat';

--
-- Data for Name: log_auditoria; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.log_auditoria (id_log, usuario, operacion, tabla, datos, fecha) FROM stdin;
\.
COPY public.log_auditoria (id_log, usuario, operacion, tabla, datos, fecha) FROM '$$PATH$$/5953.dat';

--
-- Data for Name: orden; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.orden (id_orden, fecha_orden, estado, id_cliente, total) FROM stdin;
\.
COPY public.orden (id_orden, fecha_orden, estado, id_cliente, total) FROM '$$PATH$$/5945.dat';

--
-- Data for Name: producto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.producto (id_producto, nombre, descripcion, precio, stock, estado, id_categoria) FROM stdin;
\.
COPY public.producto (id_producto, nombre, descripcion, precio, stock, estado, id_categoria) FROM '$$PATH$$/5943.dat';

--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM stdin;
\.
COPY public.spatial_ref_sys (srid, auth_name, auth_srid, srtext, proj4text) FROM '$$PATH$$/5733.dat';

--
-- Data for Name: topology; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.topology (id, name, srid, "precision", hasz) FROM stdin;
\.
COPY topology.topology (id, name, srid, "precision", hasz) FROM '$$PATH$$/5735.dat';

--
-- Data for Name: layer; Type: TABLE DATA; Schema: topology; Owner: postgres
--

COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM stdin;
\.
COPY topology.layer (topology_id, layer_id, schema_name, table_name, feature_column, feature_type, level, child_id) FROM '$$PATH$$/5736.dat';

--
-- Name: almacen_id_almacen_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.almacen_id_almacen_seq', 1, false);


--
-- Name: almacen_producto_id_almacen_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.almacen_producto_id_almacen_producto_seq', 1, false);


--
-- Name: categoria_id_categoria_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.categoria_id_categoria_seq', 1, false);


--
-- Name: cliente_id_cliente_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cliente_id_cliente_seq', 1, false);


--
-- Name: detalle_orden_id_detalle_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.detalle_orden_id_detalle_seq', 1, false);


--
-- Name: log_auditoria_id_log_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.log_auditoria_id_log_seq', 1, false);


--
-- Name: orden_id_orden_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.orden_id_orden_seq', 1, false);


--
-- Name: producto_id_producto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.producto_id_producto_seq', 1, false);


--
-- Name: topology_id_seq; Type: SEQUENCE SET; Schema: topology; Owner: postgres
--

SELECT pg_catalog.setval('topology.topology_id_seq', 1, false);


--
-- Name: almacen almacen_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.almacen
    ADD CONSTRAINT almacen_pkey PRIMARY KEY (id_almacen);


--
-- Name: almacen_producto almacen_producto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.almacen_producto
    ADD CONSTRAINT almacen_producto_pkey PRIMARY KEY (id_almacen_producto);


--
-- Name: categoria categoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.categoria
    ADD CONSTRAINT categoria_pkey PRIMARY KEY (id_categoria);


--
-- Name: cliente cliente_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cliente
    ADD CONSTRAINT cliente_pkey PRIMARY KEY (id_cliente);


--
-- Name: detalle_orden detalle_orden_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_orden
    ADD CONSTRAINT detalle_orden_pkey PRIMARY KEY (id_detalle);


--
-- Name: log_auditoria log_auditoria_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.log_auditoria
    ADD CONSTRAINT log_auditoria_pkey PRIMARY KEY (id_log);


--
-- Name: orden orden_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden
    ADD CONSTRAINT orden_pkey PRIMARY KEY (id_orden);


--
-- Name: producto producto_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto
    ADD CONSTRAINT producto_pkey PRIMARY KEY (id_producto);


--
-- Name: almacen trg_auditoria_almacen; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auditoria_almacen AFTER INSERT OR DELETE OR UPDATE ON public.almacen FOR EACH ROW EXECUTE FUNCTION public.fn_registrar_auditoria();


--
-- Name: almacen_producto trg_auditoria_almacen_producto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auditoria_almacen_producto AFTER INSERT OR DELETE OR UPDATE ON public.almacen_producto FOR EACH ROW EXECUTE FUNCTION public.fn_registrar_auditoria();


--
-- Name: categoria trg_auditoria_categoria; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auditoria_categoria AFTER INSERT OR DELETE OR UPDATE ON public.categoria FOR EACH ROW EXECUTE FUNCTION public.fn_registrar_auditoria();


--
-- Name: cliente trg_auditoria_cliente; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auditoria_cliente AFTER INSERT OR DELETE OR UPDATE ON public.cliente FOR EACH ROW EXECUTE FUNCTION public.fn_registrar_auditoria();


--
-- Name: detalle_orden trg_auditoria_detalle_orden; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auditoria_detalle_orden AFTER INSERT OR DELETE OR UPDATE ON public.detalle_orden FOR EACH ROW EXECUTE FUNCTION public.fn_registrar_auditoria();


--
-- Name: orden trg_auditoria_orden; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auditoria_orden AFTER INSERT OR DELETE OR UPDATE ON public.orden FOR EACH ROW EXECUTE FUNCTION public.fn_registrar_auditoria();


--
-- Name: producto trg_auditoria_producto; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_auditoria_producto AFTER INSERT OR DELETE OR UPDATE ON public.producto FOR EACH ROW EXECUTE FUNCTION public.fn_registrar_auditoria();


--
-- Name: detalle_orden trg_gestionar_inventario_detalle; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trg_gestionar_inventario_detalle AFTER INSERT OR DELETE ON public.detalle_orden FOR EACH ROW EXECUTE FUNCTION public.fn_gestionar_inventario();


--
-- Name: almacen_producto almacen_producto_id_almacen_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.almacen_producto
    ADD CONSTRAINT almacen_producto_id_almacen_fkey FOREIGN KEY (id_almacen) REFERENCES public.almacen(id_almacen);


--
-- Name: almacen_producto almacen_producto_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.almacen_producto
    ADD CONSTRAINT almacen_producto_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto);


--
-- Name: detalle_orden detalle_orden_id_orden_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_orden
    ADD CONSTRAINT detalle_orden_id_orden_fkey FOREIGN KEY (id_orden) REFERENCES public.orden(id_orden);


--
-- Name: detalle_orden detalle_orden_id_producto_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.detalle_orden
    ADD CONSTRAINT detalle_orden_id_producto_fkey FOREIGN KEY (id_producto) REFERENCES public.producto(id_producto);


--
-- Name: orden orden_id_cliente_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.orden
    ADD CONSTRAINT orden_id_cliente_fkey FOREIGN KEY (id_cliente) REFERENCES public.cliente(id_cliente);


--
-- Name: producto producto_id_categoria_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.producto
    ADD CONSTRAINT producto_id_categoria_fkey FOREIGN KEY (id_categoria) REFERENCES public.categoria(id_categoria);


--
-- PostgreSQL database dump complete
--

